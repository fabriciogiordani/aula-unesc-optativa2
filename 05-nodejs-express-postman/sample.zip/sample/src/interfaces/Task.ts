export interface Task {
  name: string;
  percent: number;
}
